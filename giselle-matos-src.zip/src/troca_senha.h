#ifndef TROCA_SENHA_H
#define TROCA_SENHA_H

void Troca_senha(struct dados_user *usuario_logado);
/*!
 * Mostra_posts(): função responsável por mostrar os posts existentes associados
 * ao usuario logado no momento.
 * @param struct posts *lista_posts - Nó da lista encadeada contendo a postagem e o nome
 * usuário responsavel pela postagem
 */

#endif

