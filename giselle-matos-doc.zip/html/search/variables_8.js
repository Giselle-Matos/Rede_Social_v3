var searchData=
[
  ['parent_0',['parent',['../structdados__user.html#a2e436b030c14102d8f91b49b367c172b',1,'dados_user']]],
  ['post_1',['post',['../structmural__grupo.html#a5340f0a4efb942a6b0f8f761463a8713',1,'mural_grupo']]],
  ['postagem_2',['postagem',['../structposts.html#a12bba987871c3110e156c6e4d71972e7',1,'posts']]],
  ['posts_3',['posts',['../structdados__user.html#a0ff022467a1b43f01cf7a52c680606d7',1,'dados_user']]],
  ['prox_4',['prox',['../structmural__grupo.html#a470498b87947f49037e65ddf2efc19a4',1,'mural_grupo::prox'],['../structgrupos__users.html#a504d05e2026da4528df8f0945a7369fa',1,'grupos_users::prox'],['../structgrupos.html#a2a91cf646050ee0a7c1b1c0d3751d76a',1,'grupos::prox'],['../structmensagens.html#a0b56936b794bf3360d01d0342ca131aa',1,'mensagens::prox'],['../structposts.html#aab065246e0cfea9d16b46192d436063a',1,'posts::prox'],['../structdados__user.html#ab30bbd6534d9be00996658d4e9eb6051',1,'dados_user::prox']]]
];
