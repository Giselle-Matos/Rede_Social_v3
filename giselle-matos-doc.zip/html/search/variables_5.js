var searchData=
[
  ['mensagem_0',['mensagem',['../structdados__user.html#ab495446f7f27a90c686e9bab6e27f0a1',1,'dados_user']]],
  ['mural_5fg_1',['mural_g',['../structgrupos.html#a17e5f7d60192aa432ec115ce5452ace4',1,'grupos']]]
];
