var searchData=
[
  ['grupo_0',['grupo',['../structdados__user.html#afc6ea8f734fbf0d45ecc6780f417ea05',1,'dados_user']]],
  ['grupos_1',['grupos',['../structgrupos.html',1,'']]],
  ['grupos_2ec_2',['grupos.c',['../grupos_8c.html',1,'']]],
  ['grupos_2eh_3',['grupos.h',['../grupos_8h.html',1,'']]],
  ['grupos_5fusers_4',['grupos_users',['../structgrupos__users.html',1,'']]]
];
