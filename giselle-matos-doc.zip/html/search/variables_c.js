var searchData=
[
  ['user_5fpost_0',['user_post',['../structmural__grupo.html#a520525d1ae2b08414243539bc385255f',1,'mural_grupo::user_post'],['../structposts.html#a520525d1ae2b08414243539bc385255f',1,'posts::user_post']]],
  ['user_5freceive_1',['user_receive',['../structmensagens.html#a56e28edac28bd16530723fca07c3cae8',1,'mensagens']]],
  ['user_5fsend_2',['user_send',['../structmensagens.html#a9efbadf285492f661c4745fe73786d65',1,'mensagens']]],
  ['usuario_5flogado_3',['usuario_logado',['../main_8c.html#ad98101dd848af12bd38fbce6586fe2b5',1,'usuario_logado:&#160;main.c'],['../rede__social_8h.html#ad98101dd848af12bd38fbce6586fe2b5',1,'usuario_logado:&#160;main.c']]],
  ['usuarios_4',['usuarios',['../structgrupos.html#a08070013bf846d0904e19be694f49867',1,'grupos']]]
];
