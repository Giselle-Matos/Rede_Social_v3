var searchData=
[
  ['parent_0',['parent',['../structdados__user.html#a2e436b030c14102d8f91b49b367c172b',1,'dados_user']]],
  ['perfil_2ec_1',['perfil.c',['../perfil_8c.html',1,'']]],
  ['perfil_2eh_2',['perfil.h',['../perfil_8h.html',1,'']]],
  ['pesquisa_5fchat_3',['Pesquisa_chat',['../chats_8c.html#a639d0b007c8775fbf9ba10101c7b5967',1,'Pesquisa_chat(struct dados_user *usuario_logado, struct dados_user **lista_usuarios):&#160;chats.c'],['../chats_8h.html#a639d0b007c8775fbf9ba10101c7b5967',1,'Pesquisa_chat(struct dados_user *usuario_logado, struct dados_user **lista_usuarios):&#160;chats.c']]],
  ['pesquisa_5fgrupo_4',['Pesquisa_grupo',['../grupos_8c.html#ad779f01e9aadfbbc6f7da4e0bb4890ec',1,'Pesquisa_grupo(struct dados_user *usuario_logado, struct grupos *lista_grupos):&#160;grupos.c'],['../grupos_8h.html#ad779f01e9aadfbbc6f7da4e0bb4890ec',1,'Pesquisa_grupo(struct dados_user *usuario_logado, struct grupos *lista_grupos):&#160;grupos.c']]],
  ['pesquisa_5fperfil_5',['Pesquisa_perfil',['../perfil_8c.html#abbf94b779667663e14e68a7d8268389f',1,'Pesquisa_perfil(struct dados_user **lista_usuarios):&#160;perfil.c'],['../perfil_8h.html#abbf94b779667663e14e68a7d8268389f',1,'Pesquisa_perfil(struct dados_user **lista_usuarios):&#160;perfil.c']]],
  ['post_6',['post',['../structmural__grupo.html#a5340f0a4efb942a6b0f8f761463a8713',1,'mural_grupo']]],
  ['postagem_7',['postagem',['../structposts.html#a12bba987871c3110e156c6e4d71972e7',1,'posts']]],
  ['postar_8',['Postar',['../mural_8c.html#a9c6a51d03183c42b3321961f6ea105d7',1,'Postar(struct posts **lista_posts, char user[50]):&#160;mural.c'],['../mural_8h.html#a9c6a51d03183c42b3321961f6ea105d7',1,'Postar(struct posts **lista_posts, char user[50]):&#160;mural.c']]],
  ['posts_9',['posts',['../structposts.html',1,'posts'],['../structdados__user.html#a0ff022467a1b43f01cf7a52c680606d7',1,'dados_user::posts']]],
  ['prox_10',['prox',['../structmural__grupo.html#a470498b87947f49037e65ddf2efc19a4',1,'mural_grupo::prox'],['../structgrupos__users.html#a504d05e2026da4528df8f0945a7369fa',1,'grupos_users::prox'],['../structgrupos.html#a2a91cf646050ee0a7c1b1c0d3751d76a',1,'grupos::prox'],['../structmensagens.html#a0b56936b794bf3360d01d0342ca131aa',1,'mensagens::prox'],['../structposts.html#aab065246e0cfea9d16b46192d436063a',1,'posts::prox'],['../structdados__user.html#ab30bbd6534d9be00996658d4e9eb6051',1,'dados_user::prox']]]
];
