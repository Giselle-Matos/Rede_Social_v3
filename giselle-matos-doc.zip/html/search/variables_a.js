var searchData=
[
  ['senha_5fuser_0',['senha_user',['../structdados__user.html#aa6001cc1ac96861ade71c216cc145c1d',1,'dados_user']]]
];
