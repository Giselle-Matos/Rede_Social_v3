var searchData=
[
  ['grupos_0',['grupos',['../structgrupos.html',1,'']]],
  ['grupos_5fusers_1',['grupos_users',['../structgrupos__users.html',1,'']]]
];
