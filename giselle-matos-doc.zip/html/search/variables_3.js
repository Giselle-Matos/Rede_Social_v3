var searchData=
[
  ['grupo_0',['grupo',['../structdados__user.html#afc6ea8f734fbf0d45ecc6780f417ea05',1,'dados_user']]]
];
