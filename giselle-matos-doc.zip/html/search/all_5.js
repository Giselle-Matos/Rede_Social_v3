var searchData=
[
  ['find_5ffriendship_0',['Find_friendship',['../friendlist_8c.html#a32b5d0a49e573b7c070012e573a50639',1,'Find_friendship(struct dados_user *usuario_logado, char *username_friend, struct dados_user **lista_usuarios):&#160;friendlist.c'],['../friendlist_8h.html#a32b5d0a49e573b7c070012e573a50639',1,'Find_friendship(struct dados_user *usuario_logado, char *username_friend, struct dados_user **lista_usuarios):&#160;friendlist.c']]],
  ['find_5fset_1',['Find_set',['../friendlist_8c.html#a0b7d40ef68d48782af6506cc27c813c0',1,'Find_set(struct dados_user *usuario):&#160;friendlist.c'],['../friendlist_8h.html#a0b7d40ef68d48782af6506cc27c813c0',1,'Find_set(struct dados_user *usuario):&#160;friendlist.c']]],
  ['friendlist_2ec_2',['friendlist.c',['../friendlist_8c.html',1,'']]],
  ['friendlist_2eh_3',['friendlist.h',['../friendlist_8h.html',1,'']]]
];
