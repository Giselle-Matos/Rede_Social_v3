var searchData=
[
  ['grupos_2ec_0',['grupos.c',['../grupos_8c.html',1,'']]],
  ['grupos_2eh_1',['grupos.h',['../grupos_8h.html',1,'']]]
];
