var searchData=
[
  ['ocupacao_5fsocial_5fuser_0',['ocupacao_social_user',['../structdados__user.html#a3f44966016e60c4c1fad7fe0dbdb5a70',1,'dados_user']]]
];
