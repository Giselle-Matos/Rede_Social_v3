var searchData=
[
  ['lider_5fgrupo_0',['lider_grupo',['../structgrupos.html#a3aa12c63c8c6764ff18de16ff6c4b5f2',1,'grupos']]],
  ['lista_5famigos_1',['lista_amigos',['../structdados__user.html#a73cc99a9b19e5822a7d3b9a04919c44c',1,'dados_user']]],
  ['lista_5fgrupos_2',['lista_grupos',['../main_8c.html#aa376534395e3a9fc5196beaa2014c437',1,'lista_grupos:&#160;main.c'],['../rede__social_8h.html#aa376534395e3a9fc5196beaa2014c437',1,'lista_grupos:&#160;main.c']]]
];
