var searchData=
[
  ['friendlist_2ec_0',['friendlist.c',['../friendlist_8c.html',1,'']]],
  ['friendlist_2eh_1',['friendlist.h',['../friendlist_8h.html',1,'']]]
];
