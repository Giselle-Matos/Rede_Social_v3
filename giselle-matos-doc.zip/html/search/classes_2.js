var searchData=
[
  ['mensagens_0',['mensagens',['../structmensagens.html',1,'']]],
  ['mural_5fgrupo_1',['mural_grupo',['../structmural__grupo.html',1,'']]]
];
