var searchData=
[
  ['biografia_5fuser_0',['biografia_user',['../structdados__user.html#adb870f7b849aba7e53e1c974ae936f5c',1,'dados_user']]],
  ['busca_5fposts_1',['Busca_posts',['../mural_8c.html#aaf4408bbf797eb1fb6eb7d947e676836',1,'Busca_posts(struct dados_user *lista_usuarios, char busca_post_user[50]):&#160;mural.c'],['../mural_8h.html#aaf4408bbf797eb1fb6eb7d947e676836',1,'Busca_posts(struct dados_user *lista_usuarios, char busca_post_user[50]):&#160;mural.c']]]
];
