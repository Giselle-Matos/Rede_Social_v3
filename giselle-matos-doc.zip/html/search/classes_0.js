var searchData=
[
  ['dados_5fuser_0',['dados_user',['../structdados__user.html',1,'']]]
];
