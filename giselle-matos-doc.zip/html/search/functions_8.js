var searchData=
[
  ['remove_5famigo_0',['Remove_amigo',['../friendlist_8c.html#aad021d511bfb2538100d372c2d407057',1,'Remove_amigo(struct dados_user *usuario_logado, char *username_friend):&#160;friendlist.c'],['../friendlist_8h.html#aad021d511bfb2538100d372c2d407057',1,'Remove_amigo(struct dados_user *usuario_logado, char *username_friend):&#160;friendlist.c']]]
];
