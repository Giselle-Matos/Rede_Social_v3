var searchData=
[
  ['biografia_5fuser_0',['biografia_user',['../structdados__user.html#adb870f7b849aba7e53e1c974ae936f5c',1,'dados_user']]]
];
