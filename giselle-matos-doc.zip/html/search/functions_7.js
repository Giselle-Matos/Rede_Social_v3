var searchData=
[
  ['pesquisa_5fchat_0',['Pesquisa_chat',['../chats_8c.html#a639d0b007c8775fbf9ba10101c7b5967',1,'Pesquisa_chat(struct dados_user *usuario_logado, struct dados_user **lista_usuarios):&#160;chats.c'],['../chats_8h.html#a639d0b007c8775fbf9ba10101c7b5967',1,'Pesquisa_chat(struct dados_user *usuario_logado, struct dados_user **lista_usuarios):&#160;chats.c']]],
  ['pesquisa_5fgrupo_1',['Pesquisa_grupo',['../grupos_8c.html#ad779f01e9aadfbbc6f7da4e0bb4890ec',1,'Pesquisa_grupo(struct dados_user *usuario_logado, struct grupos *lista_grupos):&#160;grupos.c'],['../grupos_8h.html#ad779f01e9aadfbbc6f7da4e0bb4890ec',1,'Pesquisa_grupo(struct dados_user *usuario_logado, struct grupos *lista_grupos):&#160;grupos.c']]],
  ['pesquisa_5fperfil_2',['Pesquisa_perfil',['../perfil_8c.html#abbf94b779667663e14e68a7d8268389f',1,'Pesquisa_perfil(struct dados_user **lista_usuarios):&#160;perfil.c'],['../perfil_8h.html#abbf94b779667663e14e68a7d8268389f',1,'Pesquisa_perfil(struct dados_user **lista_usuarios):&#160;perfil.c']]],
  ['postar_3',['Postar',['../mural_8c.html#a9c6a51d03183c42b3321961f6ea105d7',1,'Postar(struct posts **lista_posts, char user[50]):&#160;mural.c'],['../mural_8h.html#a9c6a51d03183c42b3321961f6ea105d7',1,'Postar(struct posts **lista_posts, char user[50]):&#160;mural.c']]]
];
