var searchData=
[
  ['main_0',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.c']]],
  ['main_5ffriendlist_1',['Main_friendlist',['../friendlist_8c.html#aa1a7694afc57c413454f08b6e2a6af97',1,'Main_friendlist(struct dados_user *usuario_logado, struct dados_user **lista_usuarios):&#160;friendlist.c'],['../friendlist_8h.html#aa1a7694afc57c413454f08b6e2a6af97',1,'Main_friendlist(struct dados_user *usuario_logado, struct dados_user **lista_usuarios):&#160;friendlist.c']]],
  ['make_5fset_2',['Make_set',['../friendlist_8c.html#a48320a4f898b41201a27d95e0dfbb059',1,'Make_set(struct dados_user **lista_usuarios):&#160;friendlist.c'],['../friendlist_8h.html#a48320a4f898b41201a27d95e0dfbb059',1,'Make_set(struct dados_user **lista_usuarios):&#160;friendlist.c']]],
  ['mostra_5fmural_5fgrupo_3',['Mostra_mural_grupo',['../grupos_8c.html#a241d9fb1b2f807e84cbf40f9139bf9bc',1,'grupos.c']]],
  ['mostra_5fposts_4',['Mostra_posts',['../mural_8c.html#a814b08da4279334600e15f7ce300f3ae',1,'Mostra_posts(struct dados_user *lista_usuarios):&#160;mural.c'],['../mural_8h.html#a814b08da4279334600e15f7ce300f3ae',1,'Mostra_posts(struct dados_user *lista_usuarios):&#160;mural.c']]]
];
