var searchData=
[
  ['liberar_5fgrupo_5fusers_0',['Liberar_grupo_users',['../grupos_8c.html#ad28817da89e7ba3beecd1790615354bc',1,'Liberar_grupo_users(struct grupos_users *usuarios):&#160;grupos.c'],['../grupos_8h.html#ad28817da89e7ba3beecd1790615354bc',1,'Liberar_grupo_users(struct grupos_users *usuarios):&#160;grupos.c']]],
  ['liberar_5fgrupos_1',['Liberar_grupos',['../grupos_8c.html#a489fb4a46e6f3ac39f161594805a8525',1,'Liberar_grupos(struct grupos **lista_grupos):&#160;grupos.c'],['../grupos_8h.html#a489fb4a46e6f3ac39f161594805a8525',1,'Liberar_grupos(struct grupos **lista_grupos):&#160;grupos.c']]],
  ['liberar_5fmensagens_2',['Liberar_mensagens',['../chats_8c.html#ae1386a45151e4bd16262424850548047',1,'Liberar_mensagens():&#160;chats.c'],['../grupos_8h.html#ae1386a45151e4bd16262424850548047',1,'Liberar_mensagens():&#160;chats.c']]],
  ['liberar_5fmural_5fgrupo_3',['Liberar_mural_grupo',['../grupos_8c.html#accab34ced54ed1bcd5fc49f86094c3bc',1,'grupos.c']]],
  ['liberar_5fposts_4',['Liberar_posts',['../mural_8c.html#a599224855f6f98df11143be610b8ad25',1,'Liberar_posts(struct dados_user **lista_posts):&#160;mural.c'],['../mural_8h.html#a599224855f6f98df11143be610b8ad25',1,'Liberar_posts(struct dados_user **lista_posts):&#160;mural.c']]],
  ['liberar_5fusuarios_5',['Liberar_usuarios',['../login__cadastro_8c.html#aab302c0cc77328fbba161d503a1be863',1,'Liberar_usuarios(struct dados_user **lista_usuarios):&#160;login_cadastro.c'],['../login__cadastro_8h.html#aab302c0cc77328fbba161d503a1be863',1,'Liberar_usuarios(struct dados_user **lista_usuarios):&#160;login_cadastro.c']]],
  ['lider_5fgrupo_6',['lider_grupo',['../structgrupos.html#a3aa12c63c8c6764ff18de16ff6c4b5f2',1,'grupos']]],
  ['lista_5famigos_7',['lista_amigos',['../structdados__user.html#a73cc99a9b19e5822a7d3b9a04919c44c',1,'dados_user']]],
  ['lista_5fgrupos_8',['lista_grupos',['../main_8c.html#aa376534395e3a9fc5196beaa2014c437',1,'lista_grupos:&#160;main.c'],['../rede__social_8h.html#aa376534395e3a9fc5196beaa2014c437',1,'lista_grupos:&#160;main.c']]],
  ['listar_5famigos_9',['Listar_amigos',['../friendlist_8c.html#a40d2c704608ce6126239e4e1eafa2218',1,'Listar_amigos(struct dados_user *usuario_logado):&#160;friendlist.c'],['../friendlist_8h.html#a40d2c704608ce6126239e4e1eafa2218',1,'Listar_amigos(struct dados_user *usuario_logado):&#160;friendlist.c']]],
  ['login_10',['Login',['../login__cadastro_8c.html#af2f80ca913a7f661382ea8c0354100d3',1,'Login(struct dados_user **lista_usuarios, int *login_sucesso, struct dados_user **usuario_logado):&#160;login_cadastro.c'],['../login__cadastro_8h.html#af2f80ca913a7f661382ea8c0354100d3',1,'Login(struct dados_user **lista_usuarios, int *login_sucesso, struct dados_user **usuario_logado):&#160;login_cadastro.c']]],
  ['login_5fcadastro_2ec_11',['login_cadastro.c',['../login__cadastro_8c.html',1,'']]],
  ['login_5fcadastro_2eh_12',['login_cadastro.h',['../login__cadastro_8h.html',1,'']]]
];
