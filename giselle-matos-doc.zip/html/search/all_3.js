var searchData=
[
  ['dados_5fuser_0',['dados_user',['../structdados__user.html',1,'']]],
  ['descricao_1',['descricao',['../structgrupos.html#a488d5cc0d70046c7aa25b1e975bc97a9',1,'grupos']]]
];
