var searchData=
[
  ['nome_5fcompleto_5fuser_0',['nome_completo_user',['../structdados__user.html#a75e844ea16f079ec78589e3f54ae33ab',1,'dados_user']]],
  ['nome_5fgrupo_1',['nome_grupo',['../structgrupos.html#a97b98b7678212a7b18fe421bf06eb83c',1,'grupos']]],
  ['nome_5fuser_2',['nome_user',['../structdados__user.html#a8fc9bee922224a00a9bfec274899d5b9',1,'dados_user']]],
  ['nome_5fusers_3',['nome_users',['../structgrupos__users.html#ac35e8e7dbce1d92b69cb143e303db0da',1,'grupos_users']]]
];
