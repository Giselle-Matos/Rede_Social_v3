var searchData=
[
  ['chats_2ec_0',['chats.c',['../chats_8c.html',1,'']]],
  ['chats_2eh_1',['chats.h',['../chats_8h.html',1,'']]]
];
