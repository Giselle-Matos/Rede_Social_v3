var searchData=
[
  ['perfil_2ec_0',['perfil.c',['../perfil_8c.html',1,'']]],
  ['perfil_2eh_1',['perfil.h',['../perfil_8h.html',1,'']]]
];
