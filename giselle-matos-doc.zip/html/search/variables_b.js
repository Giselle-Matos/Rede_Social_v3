var searchData=
[
  ['text_0',['text',['../structmensagens.html#a726089dd59feb587fb117f603bd76db5',1,'mensagens']]]
];
