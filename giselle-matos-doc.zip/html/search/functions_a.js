var searchData=
[
  ['troca_5fsenha_0',['Troca_senha',['../troca__senha_8c.html#a2135a18c90f4bce5dcb53899ae170a6b',1,'Troca_senha(struct dados_user *usuario_logado):&#160;troca_senha.c'],['../troca__senha_8h.html#a2135a18c90f4bce5dcb53899ae170a6b',1,'Troca_senha(struct dados_user *usuario_logado):&#160;troca_senha.c']]]
];
