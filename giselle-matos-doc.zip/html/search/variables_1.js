var searchData=
[
  ['descricao_0',['descricao',['../structgrupos.html#a488d5cc0d70046c7aa25b1e975bc97a9',1,'grupos']]]
];
