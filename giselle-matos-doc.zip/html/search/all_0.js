var searchData=
[
  ['adiciona_5famigo_0',['Adiciona_amigo',['../friendlist_8c.html#a21b8191fca2c159a7424daf09fc4c356',1,'Adiciona_amigo(struct dados_user *usuario_logado, struct dados_user **lista_usuarios, char *username_friend):&#160;friendlist.c'],['../friendlist_8h.html#a21b8191fca2c159a7424daf09fc4c356',1,'Adiciona_amigo(struct dados_user *usuario_logado, struct dados_user **lista_usuarios, char *username_friend):&#160;friendlist.c']]],
  ['adiciona_5fpost_5fgrupo_1',['Adiciona_post_grupo',['../grupos_8c.html#a78d4b9322aae50d855fd6df545789610',1,'grupos.c']]],
  ['adicionar_5fusuario_2',['Adicionar_usuario',['../login__cadastro_8c.html#ace68f9654bdae7b68b0bb94d431a1ce3',1,'Adicionar_usuario(struct dados_user **lista_usuarios, struct dados_user *novo_usuario):&#160;login_cadastro.c'],['../login__cadastro_8h.html#ace68f9654bdae7b68b0bb94d431a1ce3',1,'Adicionar_usuario(struct dados_user **lista_usuarios, struct dados_user *novo_usuario):&#160;login_cadastro.c']]],
  ['apaga_5fpost_3',['Apaga_post',['../mural_8c.html#a5d5d61656474b4f9fc13c04c99d2f4fb',1,'Apaga_post(struct posts **lista_posts, int post_number):&#160;mural.c'],['../mural_8h.html#a5d5d61656474b4f9fc13c04c99d2f4fb',1,'Apaga_post(struct posts **lista_posts, int post_number):&#160;mural.c']]]
];
