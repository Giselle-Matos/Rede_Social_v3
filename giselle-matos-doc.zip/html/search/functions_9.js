var searchData=
[
  ['setconsolecolor_0',['setConsoleColor',['../main_8c.html#a3ebfca17648870bd0b802e3742db1b51',1,'setConsoleColor(int color):&#160;main.c'],['../rede__social_8h.html#a3ebfca17648870bd0b802e3742db1b51',1,'setConsoleColor(int color):&#160;main.c']]]
];
