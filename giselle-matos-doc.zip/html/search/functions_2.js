var searchData=
[
  ['clearscreen_0',['clearScreen',['../main_8c.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;main.c'],['../rede__social_8h.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;main.c']]],
  ['cria_5fgrupo_1',['Cria_grupo',['../grupos_8c.html#a4ae645131a34b1194dee97dee35f5f27',1,'Cria_grupo(struct dados_user *usuario_logado, struct grupos **lista_grupos):&#160;grupos.c'],['../grupos_8h.html#a4ae645131a34b1194dee97dee35f5f27',1,'Cria_grupo(struct dados_user *usuario_logado, struct grupos **lista_grupos):&#160;grupos.c']]],
  ['cria_5fpost_5fgrupo_2',['Cria_post_grupo',['../grupos_8c.html#a6671775ce701492dece096fbffe1a3e3',1,'grupos.c']]],
  ['criar_5fconta_3',['Criar_conta',['../login__cadastro_8c.html#a9921c51eb48c84b4d40c811372d58a63',1,'Criar_conta(struct dados_user **lista_usuarios):&#160;login_cadastro.c'],['../login__cadastro_8h.html#a9921c51eb48c84b4d40c811372d58a63',1,'Criar_conta(struct dados_user **lista_usuarios):&#160;login_cadastro.c']]],
  ['criar_5fusuario_4',['Criar_usuario',['../login__cadastro_8c.html#a65f96533dc96b81f5229c3c09c0dd563',1,'Criar_usuario():&#160;login_cadastro.c'],['../login__cadastro_8h.html#a65f96533dc96b81f5229c3c09c0dd563',1,'Criar_usuario():&#160;login_cadastro.c']]]
];
