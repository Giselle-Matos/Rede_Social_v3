var searchData=
[
  ['rank_0',['rank',['../structdados__user.html#a6cfd95afd0afebd625b889fb6e58371c',1,'dados_user']]],
  ['rede_5fsocial_2eh_1',['rede_social.h',['../rede__social_8h.html',1,'']]],
  ['remove_5famigo_2',['Remove_amigo',['../friendlist_8c.html#aad021d511bfb2538100d372c2d407057',1,'Remove_amigo(struct dados_user *usuario_logado, char *username_friend):&#160;friendlist.c'],['../friendlist_8h.html#aad021d511bfb2538100d372c2d407057',1,'Remove_amigo(struct dados_user *usuario_logado, char *username_friend):&#160;friendlist.c']]]
];
