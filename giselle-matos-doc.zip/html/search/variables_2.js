var searchData=
[
  ['endereco_5fuser_0',['endereco_user',['../structdados__user.html#a13d5a7be0e1be0ea65407fa8ccdc5693',1,'dados_user']]]
];
