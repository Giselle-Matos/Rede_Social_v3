var searchData=
[
  ['senha_5fuser_0',['senha_user',['../structdados__user.html#aa6001cc1ac96861ade71c216cc145c1d',1,'dados_user']]],
  ['setconsolecolor_1',['setConsoleColor',['../main_8c.html#a3ebfca17648870bd0b802e3742db1b51',1,'setConsoleColor(int color):&#160;main.c'],['../rede__social_8h.html#a3ebfca17648870bd0b802e3742db1b51',1,'setConsoleColor(int color):&#160;main.c']]]
];
