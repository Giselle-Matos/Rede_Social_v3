var searchData=
[
  ['busca_5fposts_0',['Busca_posts',['../mural_8c.html#aaf4408bbf797eb1fb6eb7d947e676836',1,'Busca_posts(struct dados_user *lista_usuarios, char busca_post_user[50]):&#160;mural.c'],['../mural_8h.html#aaf4408bbf797eb1fb6eb7d947e676836',1,'Busca_posts(struct dados_user *lista_usuarios, char busca_post_user[50]):&#160;mural.c']]]
];
