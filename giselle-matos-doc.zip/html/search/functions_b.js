var searchData=
[
  ['union_0',['Union',['../friendlist_8c.html#a08c06c47491f42f91ffcd3454ad5a8cf',1,'Union(struct dados_user *rep1, struct dados_user *rep2):&#160;friendlist.c'],['../friendlist_8h.html#a08c06c47491f42f91ffcd3454ad5a8cf',1,'Union(struct dados_user *rep1, struct dados_user *rep2):&#160;friendlist.c']]]
];
