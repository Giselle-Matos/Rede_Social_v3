var searchData=
[
  ['text_0',['text',['../structmensagens.html#a726089dd59feb587fb117f603bd76db5',1,'mensagens']]],
  ['troca_5fsenha_1',['Troca_senha',['../troca__senha_8c.html#a2135a18c90f4bce5dcb53899ae170a6b',1,'Troca_senha(struct dados_user *usuario_logado):&#160;troca_senha.c'],['../troca__senha_8h.html#a2135a18c90f4bce5dcb53899ae170a6b',1,'Troca_senha(struct dados_user *usuario_logado):&#160;troca_senha.c']]],
  ['troca_5fsenha_2ec_2',['troca_senha.c',['../troca__senha_8c.html',1,'']]],
  ['troca_5fsenha_2eh_3',['troca_senha.h',['../troca__senha_8h.html',1,'']]]
];
